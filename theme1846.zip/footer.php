			</div>
        </div>
    </div>
    
    
    <?php if( is_front_page() ) { ?>
    	<div class="extra_content">
        	<div class="container">
                <div class="container_12 clearfix">
                    <div class="grid_12">
						<?php if ( ! dynamic_sidebar( 'Content Area 4' ) ) : ?>
                            <!--Widgetized 'Content Area' for the home page-->
                        <?php endif ?>
                    </div>
                 </div>
             </div>
        </div>
    <?php } ?>
    
    
	<footer id="footer">
    
    <div id="back-top-wrapper">
        <p id="back-top">
            <a href="#top"><span></span></a>
        </p>
    </div>
        
        <?php if( is_front_page() ) { ?>
            <div class="footer_widget_area">
                <div class="container_12 clearfix">
                    <div class="grid_12">
                        <div class="wrapper">
                
                            <div class="grid_3 alpha">
                                <?php if ( ! dynamic_sidebar( 'Footer Area 1' ) ) : ?>
                                    <!--Widgetized Footer-->
                                <?php endif ?>
                            </div>
                            
                            <div class="grid_3 prefix_1 suffix_1">
                                <?php if ( ! dynamic_sidebar( 'Footer Area 2' ) ) : ?>
                                    <!--Widgetized Footer-->
                                <?php endif ?>
                            </div>
                            
                            <div class="grid_4 omega">
                                <?php if ( ! dynamic_sidebar( 'Footer Area 3' ) ) : ?>
                                    <!--Widgetized Footer-->
                                <?php endif ?>
                            </div>
                        
                        </div>
                    </div>
                </div>
            </div>
        <?php } ?>
        
        <div class="footer_info">
            <div class="container_12 clearfix">
                <div class="grid_12">
                	<div class="wrapper">
    
						<?php if ( of_get_option('footer_menu') == 'true') { ?>  
                            <nav class="footer">
                                <?php wp_nav_menu( array(
                                    'container'       => 'ul', 
                                    'menu_class'      => 'footer-nav', 
                                    'depth'           => 0,
                                    'theme_location' => 'footer_menu' 
                                  )); 
                                ?>
                            </nav>
                        <?php } ?>
                        
                        <div id="footer-text">
                            <?php $myfooter_text = of_get_option('footer_text'); ?>
                            <?php if($myfooter_text){?>
                                <?php echo of_get_option('footer_text'); ?>
                            <?php } else { ?>
                                <strong><a href="<?php bloginfo('url'); ?>/" title="<?php bloginfo('description'); ?>" class="site-name"><?php bloginfo('name'); ?></a></strong> &copy; <?php echo date ('Y'); ?> | <a href="<?php bloginfo('url'); ?>/privacy-policy/" title="Privacy Policy"><?php _e('Privacy policy', 'theme1846'); ?></a> <?php if( is_front_page() ) { ?><!-- {%FOOTER_LINK} --><?php } ?>
                            <?php } ?>
                        </div>
        			
                    </div>
                </div>
            </div>
        </div>
					
	</footer>
    
</div><!--#main-->
<?php wp_footer(); ?> <!-- this is used by many Wordpress features and for plugins to work properly -->
<?php if(of_get_option('ga_code')) { ?>
	<script type="text/javascript">
		<?php echo stripslashes(of_get_option('ga_code')); ?>
	</script>
  <!-- Show Google Analytics -->	
<?php } ?>
</body>
</html>