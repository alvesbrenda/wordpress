<?php
/**
 * Template Name: Home Page
 */

get_header(); ?>

    <div class="clearfix">
        <div class="grid_12">
            
			<?php if ( ! dynamic_sidebar( 'Content Area 1' ) ) : ?>
                <!--Widgetized 'Content Area' for the home page-->
            <?php endif ?>
            
            <div class="line_hor"></div>
            
            <div class="wrapper">
            
            	<div class="grid_7 alpha">
                
					<?php if ( ! dynamic_sidebar( 'Content Area 2' ) ) : ?>
                        <!--Widgetized 'Content Area' for the home page-->
                    <?php endif ?>
                    
                    <?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
                    	<?php the_content(); ?>
                    <?php endwhile; ?>
                    
                </div>
                
                <div class="grid_4 prefix_1 omega">
					<?php if ( ! dynamic_sidebar( 'Content Area 3' ) ) : ?>
                        <!--Widgetized 'Content Area' for the home page-->
                    <?php endif ?>
                </div>
                
            </div>
            
        </div>
    </div>
    
<?php get_footer(); ?>